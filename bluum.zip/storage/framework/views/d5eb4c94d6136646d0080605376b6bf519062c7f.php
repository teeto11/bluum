<?php $__env->startSection('header_scripts'); ?>
    <style>
        #post-unlike i{
            color: red;
        }
        .reply-unlike i{
            color: red!important;
        }
        #reply-comment{
            margin-top: 1.5rem;
        }
        #reply-comment a.close{
            font-size: 3rem;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('widgets.top-nav-bar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <main>
        <div class="container">
            <div class="nav">
                <div class="nav__categories js-dropdown">
                    <div class="nav__select">
                        <a href="/questions" class="nav__thread-btn nav__thread-btn--prev"><i class="icon-Arrow_Left"></i>Back</a>
                    </div>
                </div>
            </div>
            <div class="topics">
                <div class="topics__heading">
                    <h2 class="topics__heading-title"><?php echo e($question->title); ?></h2>
                    <div class="topics__heading-info">
                        <a href="#" class="category"><i class="bg-3ebafa"></i><?php echo e(ucfirst($question->category)); ?></a>
                        <?php if($question->tags): ?>
                            <div class="tags">
                                <?php $tags = explode(',', $question->tags); ?>
                                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="#" class="bg-4f80b0"><?php echo e($tag); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="topics__body">
                    <div class="topics__content">
                        <div class="topic">
                            <div class="topic__head">
                                <div class="topic__avatar">
                                    <a href="#" class="avatar"><img src="<?php echo e(asset('fonts/icons/avatars/'.$question->user->firstname[0].'.svg')); ?>" alt="avatar"></a>
                                </div>
                                <div class="topic__caption">
                                    <div class="topic__name">
                                        <a href="#"><?php echo e(ucwords($question->user->firstname." ".$question->user->lastname)); ?></a>
                                    </div>
                                    <div class="topic__date"><i class="icon-Watch_Later"></i><?php echo e(date("h:ia d M, Y", strtotime($question->created_at))); ?></div>
                                </div>
                            </div>
                            <div class="topic__content">
                                <div class="topic__text">
                                    <p><?php echo $question->body; ?></p>
                                </div>
                                <div class="topic__footer">
                                    <div class="topic__footer-likes">
                                        <div>
                                            <?php if(auth()->guard()->guest()): ?>
                                                <a href="#" class="post-like" id="post-like" data-target="<?php echo e($question->id); ?>" ><i class="icon-Favorite_Topic" ></i></a>
                                            <?php else: ?>
                                                <a href="#" class="post-like" id="<?php echo e($liked ? "post-unlike" : "post-like"); ?>" data-target="<?php echo e($question->id); ?>" ><i class="icon-Favorite_Topic" ></i></a>
                                            <?php endif; ?>
                                            <span id="post-<?php echo e($question->id); ?>-likes" ><?php echo e($question->likes); ?></span>
                                        </div>
                                    </div>
                                    <div class="topic__footer-share">
                                        <div data-visible="desktop">
                                            <a href="#"><i class="icon-Share_Topic"></i></a>
                                            <a href="#"><i class="icon-Flag_Topic"></i></a>
                                            <a href="#"><i class="icon-Bookmark"></i></a>
                                        </div>
                                        <div data-visible="mobile">
                                            <a href="#"><i class="icon-More_Options"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="comment" >
                            <form action="<?php echo e(route('question.answer')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="post_id" value="<?php echo e($question->id); ?>" >
                                <?php if($errors->has('body')): ?>
                                    <div class="invalid-feedback text-danger" role="alert">
                                        <p><strong><?php echo e($errors->first('body')); ?></strong></p>
                                    </div>
                                <?php endif; ?>
                                <div class="form-group" >
                                    <textarea class="form-control" name="body" style="resize: none" rows="5" ></textarea>
                                </div>
                                <div class="form-group text-right" >
                                    <input type="submit" class="btn btn-success" value="Answer" >
                                </div>
                            </form>
                        </div>
                        <?php $__currentLoopData = $question->replies->where('parent_reply', null); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $r_user = $answer->user;
                                if(auth()->user()) $userLikedReply = userLikedReply($answer->id);
                            ?>
                            <div class="topic topic--comment" id="reply-<?php echo e($answer->id); ?>" >
                                <div class="topic__head">
                                    <div class="topic__avatar">
                                        <a href="#" class="avatar"><img src="<?php echo e(asset('fonts/icons/avatars/'.getFirstLetterUppercase($r_user->firstname).'.svg')); ?>" alt="avatar"></a>
                                    </div>
                                    <div class="topic__caption">
                                        <div class="topic__name">
                                            <a href="#"><?php echo e(ucwords($r_user->firstname.' '.$r_user->lastname)); ?></a>
                                        </div>
                                        <div class="topic__date"><i class="icon-Watch_Later"></i><?php echo e(formatTime($answer->created_at)); ?></div>
                                    </div>
                                </div>
                                <div class="topic__content">
                                    <div class="topic__text">
                                        <p><?php echo e($answer->body); ?>.</p>
                                    </div>
                                    <div class="topic__footer">
                                        <div class="topic__footer-likes">
                                            <div>
                                                <a href="#" class="up-vote" data-target="<?php echo e($answer->id); ?>" ><i class="icon-Upvote"></i></a>
                                                <span><?php echo e($answer->upVote->count()); ?></span>
                                            </div>
                                            <div>
                                                <a href="#" class="down-vote" data-target="<?php echo e($answer->id); ?>" ><i class="icon-Downvote"></i></a>
                                                <span><?php echo e($answer->downVote->count()); ?></span>
                                            </div>
                                            <div>
                                                <?php if(auth()->guard()->guest()): ?>
                                                    <a href="#" class="reply-like" data-id="<?php echo e($answer->id); ?>" ><i class="icon-Favorite_Topic"></i></a>
                                                <?php else: ?>
                                                    <a href="#" class="<?php echo e(($userLikedReply) ? __('reply-unlike') : __('reply-like')); ?>" data-id="<?php echo e($answer->id); ?>" ><i class="icon-Favorite_Topic"></i></a>
                                                <?php endif; ?>
                                                <span id="reply-<?php echo e($answer->id); ?>-likes" ><?php echo e($answer->likes); ?></span>
                                            </div>
                                            <div>
                                                <a href="#" class="reply-answer" data-id="<?php echo e($answer->id); ?>" data-parent="<?php echo e($answer->id); ?>" ><i class="icon-Reply_Empty"></i></a>
                                                <span><?php echo e($question->replies->where('parent_reply', $answer->id)->count()); ?></span>
                                            </div>
                                        </div>
                                        <div class="topic__footer-share">
                                            <div data-visible="desktop">
                                                <a href="#"><i class="icon-Share_Topic"></i></a>
                                                <a href="#"><i class="icon-Flag_Topic"></i></a>
                                                <a href="#" class="active"><i class="icon-Already_Bookmarked"></i></a>
                                            </div>
                                            <div data-visible="mobile">
                                                <a href="#"><i class="icon-More_Options"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <?php $__currentLoopData = $question->replies->where('parent_reply', $answer->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a_reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="creply" >
                                            <p><strong><?php echo e($a_reply->recipient); ?></strong> <?php echo e($a_reply->body); ?>. <strong><?php echo e($a_reply->user->username); ?></strong> <a href="#" class="reply-answer" data-id="<?php echo e($a_reply->id); ?>" data-parent="<?php echo e($answer->id); ?>" ><i class="icon-Reply_Empty"></i></a></p>
                                        </div>
                                        <hr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="topics__title"><i class="icon-Watch_Later"></i>This topic will has been closed.</div>
                <div class="topics__control">
                    <a href="#" class="btn"><i class="icon-Bookmark"></i>Bookmark</a>
                    <a href="#" class="btn"><i class="icon-Share_Topic"></i>Share</a>
                    <a href="#" class="btn btn--type-02" data-visible="desktop"><i class="icon-Reply_Fill"></i>Reply</a>
                </div>
                <div class="topics__title">Suggested Questions</div>
            </div>
            <div class="posts">
                <div class="posts__head">
                    <div class="posts__topic">Post</div>
                    <div class="posts__category">Category</div>
                    <div class="posts__users">Asked By</div>
                    <div class="posts__replies">Replies</div>
                    <div class="posts__views">Views</div>
                    <div class="posts__activity">Activity</div>
                </div>
                <div class="posts__body">
                    <?php $counter = 1; ?>
                    <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r_question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="posts__item <?php echo e(($counter%2 == 0) ? 'bg-f2f4f6' : ''); ?>">
                            <div class="posts__section-left">
                                <div class="posts__topic">
                                    <div class="posts__content">
                                        <a href="/question/<?php echo e($r_question->id); ?>/<?php echo e(formatUrlString($r_question->title)); ?>">
                                            <h3><?php echo e($r_question->title); ?></h3>
                                        </a>
                                        <div class="posts__tags tags">
                                            <?php $r_tags = explode(',', $r_question->tags); ?>
                                            <?php $__currentLoopData = $r_tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r_tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a href="#" class="bg-36b7d7"><?php echo e($r_tag); ?></a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="posts__category"><a href="#" class="category"><i class="bg-4436f8"></i><?php echo e(ucfirst($r_question->category)); ?></a></div>
                            </div>
                            <div class="posts__section-right">
                                <div class="posts__users"><a href="#" class="category"><i class="bg-368f8b"></i><?php echo e(ucfirst($r_question->user->firstname)); ?></a></div>
                                <div class="posts__replies"><?php echo e(count($r_question->replies)); ?></div>
                                <div class="posts__views"><?php echo e($r_question->views); ?></div>
                                <div class="posts__activity"><?php echo e(getLastActivityTime($r_question->updated_at)); ?></div>
                            </div>
                        </div>
                        <?php $counter++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </main>
    <?php echo $__env->make('widgets.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        let running = false;

        $(".reply-like, .reply-unlike").click(function (e) {

            e.preventDefault();
            if(running) {
                alert("Don't click multiple times");
                return false;
            }

            running = true;
            let url = '';
            let likeBtn = $(this);
            let reply_id = $(this).attr('data-id');
            if (likeBtn.attr('class') === 'reply-like') url = '<?php echo e(route('reply.like')); ?>'; else url = '<?php echo e(route('reply.unlike')); ?>';

            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                method: "POST",
                url: url,
                data: { reply_id:reply_id },
            }).done(function(data){
                if(data !== 'false' && data !== ''){
                    $(`#reply-${reply_id}-likes`).html(data);
                    if(likeBtn.attr('class') === "reply-like") likeBtn.attr("class", "reply-unlike"); else likeBtn.attr("class", "reply-like");
                    running = false;
                }
            }).fail(function(e){
                if(e.status === 401) alert('You need to be logged in');
            });
        });

        $(".post-like").click(function(e){

            e.preventDefault();

            if(running) {
                alert("Don't click multiple times");
                return false;
            }

            running = true;
            let url = "";
            let likeBtn = $(this);
            if(likeBtn.attr('id') === "post-like") url = "<?php echo e(route('post.like')); ?>"; else url = "<?php echo e(route('post.unlike')); ?>";
            let post_id = $(this).attr('data-target');

            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                method: "POST",
                url: url,
                data: { post_id:post_id },
            }).done(function(data){
                if(data !== 'false' && data !== ''){
                    $(`#post-${post_id}-likes`).html(data);
                    if(likeBtn.attr('id') === "post-like") likeBtn.attr("id", "post-unlike"); else likeBtn.attr("id", "post-like");
                    running = false;
                }
            }).fail(function(e){
                if(e.status === 401) alert('You need to be logged in');
            });
        });
    </script>

    <script>
        $(".reply-answer").click(function (e) {

            e.preventDefault();
            $('#reply-comment').remove();
            let recipient = $(this).attr('data-id');
            let questionId = '<?php echo e($question->id); ?>';
            let parentId = $(this).attr('data-parent');

            let replyComment = `
                <div id="reply-comment" >
                    <form action="<?php echo e(route('question.answer')); ?>" method="post" >
                        <?php echo csrf_field(); ?>
                        <div class="form-group" style="text-align: right;" >
                            <a href="#" class="close" >
                                <span style="color: red;font-weight: bold;" >&times;</span>
                            </a>
                        </div>
                        <input type="hidden" name="recipient" value="${recipient}" >
                        <input type="hidden" name="post_id" value="${questionId}" >
                        <div class="form-group" >
                            <textarea class="form-control" name="body" style="resize: none;" ></textarea>
                        </div>
                        <div class="form-group text-right" >
                            <input type="submit" class="btn btn-success" value="Reply" >
                        </div>
                    </form>
                </div>
            `;

            $("#reply-"+parentId).append(replyComment);
        });

        $(document).on('click', '#reply-comment .close', function (e) {

            e.preventDefault();
            $("#reply-comment").remove();
        });
    </script>

    <script>

        $('.up-vote, .down-vote').click(function (e) {

            e.preventDefault();
            if(running){
                alert("Don't click multiple times");
                return false;
            }

            running = true;
            let url = '';

            if($(this).hasClass('up-vote')) url = '<?php echo e(route('question.answer.up-vote')); ?>';
            if($(this).hasClass('down-vote')) url = '<?php echo e(route('question.answer.down-vote')); ?>';

            let answerId = $(this).attr('data-target');
            let voteBtn = $(this);

            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                method: "POST",
                data: {answerId: answerId},
                url: url,
            }).done(function (res) {
                if(res !== 'false') voteBtn.next().html(res);
                running = false;
            }).fail(function(e){
                if(e.status === 401) alert('You need to be logged in');
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-temp', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>