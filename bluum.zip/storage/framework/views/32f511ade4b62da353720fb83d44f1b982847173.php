<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('widgets.top-nav-bar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <main>
        <div class="container">
            <div class="nav">
                <div class="nav__categories js-dropdown">
                    <div class="nav__select">
                        <div class="btn-select" data-dropdown-btn="categories">All Categories</div>
                        <nav class="dropdown dropdown--design-01" data-dropdown-list="categories">
                            <ul class="dropdown__catalog row">
                                <li class="col-xs-6"><a href="/questions" class="category"><i class="bg-5dd39e"></i>All</a></li>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="col-xs-6"><a href="/questions/category/<?php echo e(urlencode($category->value)); ?>" class="category"><i class="bg-5dd39e"></i><?php echo e(ucfirst($category->value)); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </nav>
                    </div>
                    <div class="nav__select">
                        <div class="btn-select" data-dropdown-btn="tags">Tags</div>
                        <div class="dropdown dropdown--design-01" data-dropdown-list="tags">
                            <div class="tags">
                                <?php $__currentLoopData = $top_tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="/questions/tag/<?php echo e(urlencode($tag->value)); ?>" class="bg-36b7d7"><?php echo e($tag->value); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="nav__menu js-dropdown">
                    <div class="nav__select">
                        <div class="btn-select" data-dropdown-btn="menu">Latest</div>
                        <div class="dropdown dropdown--design-01" data-dropdown-list="menu">
                            <ul class="dropdown__catalog">
                                <li><a href="<?php echo e(route('questions')); ?>">Latest</a></li>
                                <li><a href="<?php echo e(route('question.unread')); ?>">Unread</a></li>
                                <li><a href="<?php echo e(route('question.popular')); ?>">Most Liked</a></li>
                                <li><a href="<?php echo e(route('question.following')); ?>">Following</a></li>
                            </ul>
                        </div>
                    </div>
                    <ul>
                        <li class="filter-link" id="latest-link" ><a href="<?php echo e(route('questions')); ?>">Latest</a></li>
                        <li class="filter-link" id="unread-link" ><a href="<?php echo e(route('question.unread')); ?>">Unread</a></li>
                        <li class="filter-link" id="popular-link" ><a href="<?php echo e(route('question.popular')); ?>">Most Liked</a></li>
                        <li class="filter-link" id="following-link" ><a href="<?php echo e(route('question.following')); ?>">Following</a></li>
                    </ul>
                </div>
            </div>
            <div class="posts">
                <div class="posts__head">
                    <div class="posts__topic">Question</div>
                    <div class="posts__category">Category</div>
                    <div class="posts__users">Experts</div>
                    <div class="posts__replies">Replies</div>
                    <div class="posts__views">Views</div>
                    <div class="posts__activity">Activity</div>
                </div>
                <div class="posts__body">
                    <?php $counter=1; ?>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="posts__item <?php echo e(($counter%2 == 0) ? 'bg-f2f4f6' : ''); ?>">
                            <div class="posts__section-left">
                                <div class="posts__topic">
                                    <div class="posts__content">
                                        <a href="/question/<?php echo e($question->id); ?>/<?php echo e(formatUrlString($question->title)); ?>">
                                            <h3><?php echo e($question->title); ?></h3>
                                        </a>
                                        <div class="posts__tags tags">
                                            <?php $__currentLoopData = explode(',', $question->tags); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a href="#" class="bg-36b7d7"><?php echo e($tag); ?></a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="posts__category"><a href="#" class="category"><i class="bg-368f8b"></i><?php echo e(ucfirst($question->category)); ?></a></div>
                            </div>
                            <div class="posts__section-right">
                                <div class="posts__users">
                                    <?php $__currentLoopData = $question->popularReplies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div>
                                            <a href="#" class="avatar"><img src="<?php echo e(asset('fonts/icons/avatars/'.getFirstLetterUppercase($reply->user->firstname)).'.svg'); ?>" alt="avatar"></a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="posts__replies"><?php echo e(count($question->replies)); ?></div>
                                <div class="posts__views"><?php echo e($question->views); ?></div>
                                <div class="posts__activity"><?php echo e(getLastActivityTime($question->updated_at)); ?></div>
                            </div>
                        </div>
                        <?php $counter++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $posts->links(); ?>

                </div>
            </div>
        </div>
    </main>
    <?php echo $__env->make('widgets.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        let activeLink = '<?php echo e($active_link); ?>';
        $("#"+activeLink).addClass('active');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-temp', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>