<?php $__env->startSection('header_scripts'); ?>
    <style>
        .topic__footer-likes div a{
            margin-left: 7.5px;
            margin-right: 7.5px;
        }
        #post-unlike i{
            color: red;
        }
        .reply-unlike i{
            color: red!important;
        }
        #reply-comment{
            margin-top: 1.5rem;
        }
        #reply-comment a.close{
            font-size: 3rem;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('widgets.top-nav-bar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <main>
        <div class="container">
            <div class="nav">
                <div class="nav__categories js-dropdown">
                    <div class="nav__select">
                        <a href="/blog" class="nav__thread-btn nav__thread-btn--prev"><i class="icon-Arrow_Left"></i>Back</a>
                    </div>
                </div>
            </div>
            <div class="topics">
                <div class="topics__heading">
                    <?php if(auth()->user()): ?>
                        <?php if(auth()->user()->id == $post->user_id): ?>
                            <div class="text-right" >
                                <a href="/blog/post/edit/<?php echo e($post->id); ?>" >
                                    <button class="btn btn-success" >EDIT</button>
                                </a>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                    <h2 class="topics__heading-title"><?php echo e(ucwords($post->title)); ?></h2>
                    <div class="topics__heading-info">
                        <a href="#" class="category"><i class="bg-3ebafa"></i><?php echo e(ucfirst($post->category)); ?></a>
                        <?php if($post->tags): ?>
                            <div class="tags">
                                <?php $tags = explode(',', $post->tags); ?>
                                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="/blog/tag/<?php echo e($tag); ?>" class="bg-4f80b0"><?php echo e($tag); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="topics__body">
                    <div class="topics__content">
                        <div class="topic">
                            <div class="topic__head">
                                <div class="topic__avatar">
                                    <a href="#" class="avatar"><img src="<?php echo e(asset('fonts/icons/avatars/'.$post->user->firstname[0].'.svg')); ?>" alt="avatar"></a>
                                </div>
                                <div class="topic__caption">
                                    <div class="topic__name">
                                        <a href="#"><?php echo e(ucwords($post->user->firstname." ".$post->user->lastname)); ?></a>
                                    </div>
                                    <div class="topic__date"><i class="icon-Watch_Later"></i><?php echo e(date("h:ia d M, Y", strtotime($post->created_at))); ?></div>
                                </div>
                            </div>
                            <div class="topic__content">
                                <div class="topic__text">
                                    <p><?php echo $post->body; ?></p>
                                </div>
                                <div class="topic__footer">
                                    <div class="topic__footer-likes">
                                        <div>
                                            <?php if(auth()->guard()->guest()): ?>
                                                <a href="#" class="post-like" id="post-like" data-target="<?php echo e($post->id); ?>" ><i class="icon-Favorite_Topic" ></i></a>
                                            <?php else: ?>
                                                <a href="#" class="post-like" id="<?php echo e($liked ? "post-unlike" : "post-like"); ?>" data-target="<?php echo e($post->id); ?>" ><i class="icon-Favorite_Topic" ></i></a>
                                            <?php endif; ?>
                                            <span id="post-<?php echo e($post->id); ?>-likes" ><?php echo e($post->likes); ?></span>
                                        </div>
                                    </div>
                                    <div class="topic__footer-share">
                                        <div data-visible="desktop">
                                            <a href="#"><i class="icon-Share_Topic"></i></a>
                                            <a href="#"><i class="icon-Flag_Topic"></i></a>
                                            <a href="#"><i class="icon-Bookmark"></i></a>
                                        </div>
                                        <div data-visible="mobile">
                                            <a href="#"><i class="icon-More_Options"></i></a>
                                        </div>
                                        <a href="#"><i class="icon-Reply_Fill"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="comment" >
                            <form action="<?php echo e(route('blog.post.comment')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>" >
                                <?php if($errors->has('body')): ?>
                                    <div class="invalid-feedback text-danger" role="alert">
                                        <p><strong><?php echo e($errors->first('body')); ?></strong></p>
                                    </div>
                                <?php endif; ?>
                                <div class="form-group" >
                                    <textarea class="form-control" name="body" style="resize: none" rows="5" ></textarea>
                                </div>
                                <div class="form-group text-right" >
                                    <input type="submit" class="btn btn-success" value="Comment" >
                                </div>
                            </form>
                        </div>
                        <?php $__currentLoopData = $post->replies->where('parent_reply', null); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(auth()->user()) $userLikedReply = userLikedReply($reply->id); ?>
                            <div class="topic topic--comment" id="reply-<?php echo e($reply->id); ?>" >
                                <div class="topic__head">
                                    <div class="topic__avatar">
                                        <a href="#" class="avatar"><img src="<?php echo e(asset('fonts/icons/avatars/'.ucfirst($reply->user->firstname[0]).'.svg')); ?>" alt="avatar"></a>
                                    </div>
                                    <div class="topic__caption">
                                        <div class="topic__name">
                                            <a href="#"><?php echo e(ucwords($reply->user->lastname.' '.$reply->user->firstname)); ?></a>
                                        </div>
                                        <div class="topic__date">
                                            <?php if($reply->recipient): ?>
                                                <div class="topic__user topic__user--pos-r">
                                                    <i class="icon-Reply_Fill"></i>
                                                    <a href="#" class="avatar"><img src="<?php echo e(asset('fonts/icons/avatars/'.ucfirst($reply->recipient[1]).'.svg')); ?>" alt="avatar"></a>
                                                    <a href="#" class="topic__user-name"><?php echo e(ucwords($reply->recipient)); ?></a>
                                                </div>
                                            <?php endif; ?>
                                            <p><i class="icon-Watch_Later"></i><?php echo e(date("h:ia d M, Y", strtotime($reply->created_at))); ?></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="topic__content">
                                    <div class="topic__text">
                                        <p><?php echo e($reply->body); ?></p>
                                    </div>
                                    <div class="topic__footer">
                                        <div class="topic__footer-likes">
                                            <div>
                                                <?php if(auth()->guard()->guest()): ?>
                                                    <a href="#" class="reply-like" data-id="<?php echo e($reply->id); ?>" ><i class="icon-Favorite_Topic"></i></a>
                                                <?php else: ?>
                                                    <a href="#" class="<?php echo e(($userLikedReply) ? __('reply-unlike') : __('reply-like')); ?>" data-id="<?php echo e($reply->id); ?>" ><i class="icon-Favorite_Topic"></i></a>
                                                <?php endif; ?>
                                                <span id="reply-<?php echo e($reply->id); ?>-likes" ><?php echo e($reply->likes); ?></span>
                                            </div>
                                            <div>
                                                <a href="#" data-id="<?php echo e($reply->id); ?>" class="reply-comment" data-name="<?php echo e(strtolower($reply->user->firstname.' '.$reply->user->lastname)); ?>" ><i class="icon-Reply_Empty"></i></a>
                                                <span class="" ><?php echo e($post->replies->where('parent_reply', $reply->id)->count()); ?></span>
                                            </div>
                                        </div>
                                        <div class="topic__footer-share">
                                            <div data-visible="desktop">
                                                <a href="#"><i class="icon-Share_Topic"></i></a>
                                                <a href="#"><i class="icon-Flag_Topic"></i></a>
                                                <a href="#" class="active" ><i class="icon-Already_Bookmarked"></i></a>
                                            </div>
                                            <div data-visible="mobile">
                                                <a href="#"><i class="icon-More_Options"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <?php $__currentLoopData = $post->replies->where('parent_reply', $reply->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $creply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="creply" >
                                            <p><strong><?php echo e($creply->recipient); ?></strong> <?php echo e($creply->body); ?>. <strong><?php echo e($creply->user->username); ?></strong></p>
                                        </div>
                                        <hr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="topics__title"><i class="icon-Watch_Later"></i>This topic will has been closed.</div>
                <div class="topics__control">
                    <a href="#" class="btn"><i class="icon-Bookmark"></i>Bookmark</a>
                    <a href="#" class="btn"><i class="icon-Share_Topic"></i>Share</a>
                    <a href="#" class="btn btn--type-02" data-visible="desktop"><i class="icon-Reply_Fill"></i>Reply</a>
                </div>
                <div class="topics__title">Suggested Posts</div>
            </div>
            <div class="posts">
                <div class="posts__head">
                    <div class="posts__topic">Post</div>
                    <div class="posts__category">Category</div>
                    <div class="posts__users">Written By</div>
                    <div class="posts__replies">Replies</div>
                    <div class="posts__views">Views</div>
                    <div class="posts__activity">Activity</div>
                </div>
                <div class="posts__body">
                    <?php $counter = 1; ?>
                    <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rpost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="posts__item <?php echo e(($counter%2 == 0) ? 'bg-f2f4f6' : ''); ?>">
                            <?php $counter++; ?>
                            <div class="posts__section-left">
                                <div class="posts__topic">
                                    <div class="posts__content">
                                        <a href="/blog/post/<?php echo e($rpost->id); ?>/<?php echo e(formatUrlString($rpost->title)); ?>">
                                            <h3><?php echo e($rpost->title); ?></h3>
                                        </a>
                                        <div class="posts__tags tags">
                                            <?php $r_tags = explode(",", $rpost->tags) ?>
                                            <?php $__currentLoopData = $r_tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a href="#" class="bg-4f80b0"><?php echo e($tag); ?></a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="posts__category"><a href="/blog/<?php echo e(urlencode($rpost->category)); ?>" class="category"><i class="bg-368f8b"></i><?php echo e(ucfirst($rpost->category)); ?></a></div>
                            </div>
                            <div class="posts__section-right">
                                <div class="posts__users"><a class="category"><i class="bg-368f8b"></i><?php echo e(ucfirst($rpost->user->lastname)); ?></a></div>
                                <div class="posts__replies"><?php echo e(count($rpost->replies)); ?></div>
                                <div class="posts__views"><?php echo e($rpost->views); ?></div>
                                <div class="posts__activity"><?php echo e(getLastActivityTime($rpost->updated_at)); ?></div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </main>
    <?php echo $__env->make('widgets.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        let running = false;

        $(".reply-like, .reply-unlike").click(function (e) {

            e.preventDefault();
            if(running) {
                alert("Don't click multiple times");
                return false;
            }

            running = true;
            let url = '';
            let likeBtn = $(this);
            let reply_id = $(this).attr('data-id');
            if (likeBtn.attr('class') === 'reply-like') url = '<?php echo e(route('reply.like')); ?>'; else url = '<?php echo e(route('reply.unlike')); ?>';

            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                method: "POST",
                url: url,
                data: { reply_id:reply_id },
            }).done(function(data){
                if(data !== 'false' && data !== ''){
                    $(`#reply-${reply_id}-likes`).html(data);
                    if(likeBtn.attr('class') === "reply-like") likeBtn.attr("class", "reply-unlike"); else likeBtn.attr("class", "reply-like");
                    running = false;
                }
            }).fail(function(e){
                if(e.status === 401) alert('You need to be logged in');
            });
        });

        $(".post-like").click(function(e){

            e.preventDefault();

            if(running) {
                alert("Don't click multiple times");
                return false;
            }

            running = true;
            let url = "";
            let likeBtn = $(this);
            if(likeBtn.attr('id') === "post-like") url = "<?php echo e(route('post.like')); ?>"; else url = "<?php echo e(route('post.unlike')); ?>";
            let post_id = $(this).attr('data-target');

            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                method: "POST",
                url: url,
                data: { post_id:post_id },
            }).done(function(data){
                if(data !== 'false' && data !== ''){
                    $(`#post-${post_id}-likes`).html(data);
                    if(likeBtn.attr('id') === "post-like") likeBtn.attr("id", "post-unlike"); else likeBtn.attr("id", "post-like");
                    running = false;
                }
            }).fail(function(e){
                if(e.status === 401) alert('You need to be logged in');
            });
        });
    </script>

    <script>
        $(".reply-comment").click(function (e) {

            e.preventDefault();
            $('#reply-comment').remove();
            let recipient = $(this).attr('data-id');
            let postId = '<?php echo e($post->id); ?>';

            let replyComment = `
                <div id="reply-comment" >
                    <form action="<?php echo e(route('blog.post.comment')); ?>" method="post" >
                        <?php echo csrf_field(); ?>
                        <div class="form-group" style="text-align: right;" >
                            <a href="#" class="close" >
                                <span style="color: red;font-weight: bold;" >&times;</span>
                            </a>
                        </div>
                        <input type="hidden" name="recipient" value="${recipient}" >
                        <input type="hidden" name="post_id" value="${postId}" >
                        <div class="form-group" >
                            <textarea class="form-control" name="body" style="resize: none;" ></textarea>
                        </div>
                        <div class="form-group text-right" >
                            <input type="submit" class="btn btn-success" value="Reply" >
                        </div>
                    </form>
                </div>
            `;

            $("#reply-"+recipient).append(replyComment);
        });

        $(document).on('click', '#reply-comment .close', function (e) {

            e.preventDefault();
            $("#reply-comment").remove();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-temp', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>