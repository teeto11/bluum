<?php $__env->startSection('content'); ?>
    <div class="content-wrapper px-4">
        <div class="view-expert-wrapper px-4">
            <div class="row my-2">
                <div class="col-lg-8 bg-white py-3">
                    <div class="post-details">
                        <div class="table-row">
                            <div class="table-responsive bg-white">
                                <form method="post" action="<?php echo e(route('admin.expert.delete')); ?>" >
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <input name="id" type="hidden" value="<?php echo e($expert->id); ?>" >
                                    <h3 class="">Expert Details <a href="" class="btn btn-sm float-right"></a></h3><hr>
                                    <button type="submit" class="btn btn-sm float-right" ><i class="fa fa-trash"></i></button>
                                </form>
                                <table class="table table-borderless table-hover">
                                    <tbody>
                                    <tr><img src="../assets/images/fyuma.jpg" class="expert-img" alt=""></tr>
                                    <tr>
                                        <td>Name</td>
                                        <td><?php echo e(ucwords($expert->firstname.' '.$expert->lastname)); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Expertise</td>
                                        <td><?php echo e($expert->expert->expertise); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Email</td>
                                        <td><?php echo e($expert->email); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Number</td>
                                        <td><?php echo e($expert->expert->telephone); ?></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 px-1 followers py-1" style="">
                    <div class="header"><h3>Followers</h3></div>
                    <div class="body">
                        <ul>
                            <?php $__currentLoopData = $expert->followers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $fUsert = $follower->user ?>
                                <li class="px-3" > <a href="" ><?php echo e(ucwords($fUsert->firstname.' '.$fUsert->lastname)); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 px-1 all-post-wrapper py-2">
                    <div class="table-row">
                        <div class="table-responsive bg-white">
                            <h3 class="">All Post</h3><hr>
                            <table class="table table-striped table-hover">
                                <thead>
                                <tr>
                                    <th scope="" style="width:60%">Title</th>
                                    <th scope="" style="width:20%">Date</th>
                                    <th></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $recentPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(ucwords($post->title)); ?></td>
                                        <td><?php echo e(date('M d, Y', strtotime($post->created_at))); ?></td>
                                        <td><a href="/admin/post/<?php echo e($post->id); ?>" class="btn btn-warning"><i class="fa fa-eye text-light"></i></a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 px-1 py-2 all-answers-wrapper">
                    <div class="table-row">
                        <div class="table-responsive bg-white">
                            <h3 class="">Recent Responses</h3><hr>
                            <table class="table table-striped table-hover">
                                <thead>
                                <tr>
                                    <th scope="" style="width:40%">Title</th>
                                    <th scope="" style="width:40%">Response</th>
                                    <th></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $recentResponses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $response): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(ucwords($response->post->title)); ?></td>
                                        <td><?php echo e($response->body); ?></td>
                                        <td><a href="/admin/post/<?php echo e($response->post->id); ?>" class="btn btn-warning"><i class="fa fa-eye text-light"></i></a> </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>