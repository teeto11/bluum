<?php $__env->startSection('content'); ?>
    <div class="content-wrapper px-4">
        <div class="view-posts-wrapper">
            <div class="table-row">
                <div class="table-responsive bg-white px-4">
                    <h3 class="">All Post</h3><hr>
                    <table class="table table-striped table-hover">
                        <thead>
                        <tr>
                            <th scope="" >User</th>
                            <th scope="" style="width:50%">Title</th>
                            <th scope="" >Date</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(ucwords($post->user->firstname.' '.$post->user->lastname)); ?></td>
                                <td><?php echo e(ucfirst($post->title)); ?></td>
                                <td><?php echo e(date('M d, Y', strtotime($post->created_at))); ?></td>
                                <td class="text-right" >
                                    <a href="/admin/post/<?php echo e($post->id); ?>" class="btn btn-warning"><i class="fa fa-eye text-light"></i></a>
                                </td>
                                <td class="text-right" >
                                    <form action="<?php echo e(route('admin.post.delete')); ?>" method="post" >
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <input type="hidden" name="id" value="<?php echo e($post->id); ?>" >
                                        <button type="submit" class="btn btn-danger" ><i class="fa fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="my-4" >
        <?php echo e($posts->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>