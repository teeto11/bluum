<?php $__env->startSection('header_scripts'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/hover.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('widgets.top-nav-bar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="experts-wrapper">
        <div class="container experts-container">
            <h2>Meet our Experts</h2>
            <hr>
            <div class="container-fluid expert-card-wrapper" >
                <?php $__currentLoopData = $experts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $details = $expert->expert ?>
                    <div class="expert-card hvr-float ">
                        <div class="image-wrapper">
                            <img src="<?php echo e(asset('fonts/icons/avatars/'.ucfirst($expert->firstname[0]).'.svg')); ?>" class="" alt="">
                        </div>
                        <div class="details-body">
                            <section class="expert-header">
                                <h6 class="expert-name"><i class="fa fa-user-circle-o"></i><?php echo e(ucwords($expert->firstname.' '.$expert->lastname)); ?></h6>
                                <h6 class="expert-practice"><i class="fa fa-briefcase"></i> <?php echo e(ucwords($details->expertise)); ?></h6>
                            </section>
                            <section class="expert-summary">
                                <p><?php echo e(ucfirst($details->about)); ?>.</p>
                            </section>
                            <section class="expert-footer" style="" >
                                <span class="exp"><b>WORK EXPERIENCE : </b><?php echo e($details->experience); ?> YEARS</span>
                                <div class="small">
                                    <section>
                                        <?php if(auth()->user() && $expert->followers->where('user_id', auth()->user()->id)->count()): ?>
                                            <form action="<?php echo e(route('expert.unfollow')); ?>" method="post" >
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="id" value="<?php echo e($expert->id); ?>">
                                                <button type="submit" class="btn hvr-grow">UnFollow <i class="glyphicon-remove-sign"></i></button>
                                            </form>
                                        <?php elseif(auth()->user() && $expert->id == auth()->user()->id): ?>

                                        <?php else: ?>
                                            <form action="<?php echo e(route('expert.follow')); ?>" method="post" >
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="id" value="<?php echo e($expert->id); ?>">
                                                <button type="submit" class="btn hvr-grow">Follow <i class="icon-Add_User"></i></button>
                                            </form>
                                        <?php endif; ?>
                                        <a href="<?php echo e(route('expert.show', ['id' => $expert->id])); ?>" class="button" style="padding: 1rem;" ><span>View profile </span></a>
                                    </section>
                                </div>
                            </section>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div style="margin-top: 2rem" >
                    <?php echo e($experts->links()); ?>

                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('widgets.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-temp', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>