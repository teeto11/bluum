<?php $__env->startSection('content'); ?>
    <div class="content-wrapper px-4">
        <div class="view-experts-wrapper">
            <div class="table-row">
                <div class="table-responsive bg-white px-4">
                    <h3 class="">All Experts</h3><hr>
                    <table class="table table-striped table-hover">
                        <thead>
                        <tr>
                            <th scope="" style="width:25%">Expert</th>
                            <th scope="" style="width:25%">Expertise</th>
                            <th scope="" style="width:20%">Posts</th>
                            <th style="width:20%">Answers</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $experts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(ucwords($expert->firstname.' '.$expert->lastname)); ?></td>
                                <td><?php echo e($expert->expert->expertise); ?></td>
                                <td><?php echo e($expert->post->count()); ?></td>
                                <td><?php echo e($expert->replies->count()); ?></td>
                                <td><a href="/admin/expert/<?php echo e($expert->id); ?>" class="btn btn-warning"><i class="fa fa-eye text-light"></i></a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php echo e($experts->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>