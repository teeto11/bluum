<?php $__env->startSection('content'); ?>
    <div class="signup">
        <!-- MAIN -->
        <main class="signup__main">
            <img class="signup__bg" src="<?php echo e(asset('images/signup-bg.png')); ?>" alt="bg" />
            <div class="container">
                <div class="signup__container">
                    <div class="signup__logo">
                        <a href="index.html"><img src="<?php echo e(asset('images/logo_small.png')); ?>" alt="logo" />Bluumhealth</a>
                    </div>
                    <div class="signup__head">
                        <h3>Create a New Bluumhealth Account</h3>
                        <p>By singing up you can start posting, replying to topics, vote topics and many more.</p>
                    </div>
                    <div class="signup__form">
                        <div class="row" data-visible="desktop">
                            <div class="col-md-6">
                                <div class="signup__section">
                                    <label class="signup__label" for="first-name">First Name:</label>
                                    <input type="text" class="form-control" name="first-name" id="first-name" />
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="signup__section">
                                    <label class="signup__label" for="last-name">Last Name:</label>
                                    <input type="text" class="form-control" name="last-name" id="last-name" />
                                </div>
                            </div>
                        </div>
                        <div class="signup__section">
                            <label class="signup__label" for="email">Email Address:</label>
                            <input type="email" class="form-control" name="email" id="email" />
                        </div>
                        <div class="signup__section">
                            <label class="signup__label" for="password">Password:</label>
                            <div class="message-input">
                                <input type="password" class="form-control" name="password" id="password" />
                            </div>
                        </div>
                        <div class="signup__checkbox">
                            <label class="signup__box">
                                <label class="custom-checkbox">
                                    <input type="checkbox" checked="checked" />
                                    <i></i>
                                </label>
                                <span>I agree to the Terms &amp; Conditions.</span>
                            </label>
                        </div>
                        <a href="#" class="signup__btn-create btn btn--type-02">Create New Account</a>
                    </div>
                </div>
            </div>
        </main>
        <!-- FOOTER -->
        <footer class="signup__footer">
            <div class="container">
                <p class="signup__link">Already have an account? <a href="/login" class="btn">Sign In</a></p>
                <div class="signup__footer-content">
                    <ul class="signup__footer-menu">
                        <li><a href="#">Teams</a></li>
                        <li><a href="#">Privacy</a></li>
                        <li><a href="#">Send Feedback</a></li>
                        <li class="footer__copyright"><span>2018 &copy; Bluumhealth. All rights reserved.</li>
                    </ul>
                </div>
            </div>
        </footer>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-temp', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>