<!-- NAVIGATION -->
<header>
    <div class="header js-header js-dropdown">
        <div class="container">
            <div class="header__logo">
                <a class="header__link" href="/" title="Bluumhealth">
                    <h1>
                        <img src="<?php echo e(asset('images/logo_small.png')); ?>" alt="logo" />
                    </h1>
                    <div class="header__logo-btn">Bluumhealth</div>
                </a>
            </div>
            <div class="header__search">
                <form action="#">
                    <label>
                        <i class="icon-Search js-header-search-btn-open"></i>
                        <input type="search" placeholder="Search anything" class="form-control" />
                    </label>
                </form>
                <div class="header__search-close js-header-search-btn-close"><i class="icon-Cancel"></i></div>
            </div>
            <div class="header__menu">
                <a class="header__menu__link" href="<?php echo e(route('question.create')); ?>">Ask</a>
            </div>
            <div class="header__menu active">
                <a class="header__menu__link active" href="<?php echo e(route('blog')); ?>">Blog</a>
            </div>
            <div class="header__menu header__dropdown">
                <div class="header__menu-btn" data-dropdown-btn="menu">
                    Questions <i class="icon-Menu_Icon"></i>
                </div>
                <nav class="dropdown dropdown--design-01" data-dropdown-list="menu">
                    <div>
                        <ul class="dropdown__catalog row">
                            <li class="col-xs-6"><a href="<?php echo e(route('question.create')); ?>">New</a></li>
                            <li class="col-xs-6"><a href="<?php echo e(route('experts')); ?>">Experts</a></li>
                            <li class="col-xs-6"><a href="/tags">Tags</a></li>
                            <li class="col-xs-6"><a href="<?php echo e(route('question.showbycategory', 'pregnancy')); ?>">Pregnancy</a></li>
                        </ul>
                    </div>
                    <div>
                        <h3>Categories</h3>
                        <ul class="dropdown__catalog row">
                            <li class="col-xs-6"><a href="<?php echo e(route('questions')); ?>" class="category"><i class="bg-5dd39e"></i>All</a></li>
                            <li class="col-xs-6"><a href="<?php echo e(route('question.showbycategory', 'pregnancy')); ?>" class="category"><i class="bg-c49bbb"></i>Pregnancy</a></li>
                            <li class="col-xs-6"><a href="<?php echo e(route('question.showbycategory', formatUrlString('medical travels'))); ?>" class="category"><i class="bg-525252"></i>Medical travels</a></li>
                            <li class="col-xs-6"><a href="<?php echo e(route('question.showbycategory', formatUrlString('common illness'))); ?>" class="category"><i class="bg-777da7"></i>Common illness</a></li>
                            <li class="col-xs-6"><a href="<?php echo e(route('question.showbycategory', formatUrlString('special illness'))); ?>" class="category"><i class="bg-368f8b"></i>Special illness</a></li>
                        </ul>
                    </div>
                    <div>
                        <ul class="dropdown__catalog row">
                            <li class="col-xs-6"><a href="#">Forum Rules</a></li>
                            <li class="col-xs-6"><a href="<?php echo e(route('blog')); ?>">Blog</a></li>
                        </ul>
                    </div>
                </nav>
            </div>
            <?php if(auth()->guard()->guest()): ?>
                <div class="header__menu">
                    <a class="header__menu__link" href="<?php echo e(route('login')); ?>">Sign In</a>
                </div>
                <div class="header__menu">
                    <a class="header__menu__link" href="<?php echo e(route('register')); ?>">Sign Up</a>
                </div>
            <?php else: ?>
                <div class="header__user">
                    <div class="header__user-btn" data-dropdown-btn="user">
                        <img src="<?php echo e(asset('fonts/icons/avatars/'.ucfirst(Auth::user()->firstname[0]).'.svg')); ?>" alt="avatar">
                        <?php echo e(ucwords(Auth::user()->firstname.' '.Auth::user()->lastname)); ?><i class="icon-Arrow_Below"></i>
                    </div>
                    <nav class="dropdown dropdown--design-01" data-dropdown-list="user">
                        <div>
                            <div class="dropdown__icons">
                                <a href="#"><i class="icon-Bookmark"></i></a>
                                <a href="#"><i class="icon-Message"></i></a>
                                <a href="#"><i class="icon-Preferences"></i></a>
                                <a href="#"><i class="icon-Logout"></i></a>
                            </div>
                        </div>
                        <div>
                            <ul class="dropdown__catalog">
                                <?php if(auth()->user()->role == 'EXPERT'): ?>
                                    <li><a href="<?php echo e(route('expert.profile')); ?>">Dashboard</a></li>
                                    <li><a href="<?php echo e(route('expert.posts')); ?>">Topics</a></li>
                                <?php else: ?>
                                    <li><a href="<?php echo e(route('user.profile')); ?>">Profile</a></li>
                                    <li><a href="<?php echo e(route('expert.posts')); ?>">Questions</a></li>
                                <?php endif; ?>
                                
                                <li><a href="#">Notifications</a></li>
                                
                                <li>
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
            <?php endif; ?>
        </div>
        <?php if(auth()->guard()->guest()): ?>

        <?php else: ?>
            <div class="header__offset-btn">
                <a href="<?php echo e(route('blog.post.create')); ?>"><img src="<?php echo e(asset('fonts/icons/main/New_Topic.svg')); ?>" alt="New Blog Post"></a>
            </div>
        <?php endif; ?>
    </div>
</header>
