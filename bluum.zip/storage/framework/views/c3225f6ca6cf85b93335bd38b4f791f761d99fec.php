<?php $__env->startSection('header_scripts'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/hover.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('widgets.top-nav-bar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="profile-wrapper" style="margin-top: 5rem" >
        <div class="container profile-sub-wrapper">
            <div class="profile-sidebar">
                <div class="profile-sidebar-header">
                    <img src="<?php echo e(asset('fonts/icons/avatars/'.getFirstLetterUppercase($user->firstname)).'.svg'); ?>" class="" alt="">
                    <p><?php echo e(ucwords($user->firstname.' '.$user->lastname)); ?></p>
                </div>
                <div class="profile-sidebar-social hvr-float">
                    <div class="followers">
                        <p><i class="fa fa-users"></i> Following <br> <span></span></p>
                    </div>
                    <div class="post">
                        <p><i class="fa fa-sticky-note"></i> Questions <br> <span></span></p>
                    </div>
                </div>
                <div class="text-center" style="margin-top: 1rem">
                    <a href="<?php echo e(route('expert.edit')); ?>" class="edit-btn hvr-pulse" style=""><i class="fa fa-edit"></i> Edit</a>
                </div>
            </div>
            <div class="profile-main">
                <?php echo $__env->yieldContent('profile-main'); ?>
            </div>
        </div>
    </div>
    <?php echo $__env->make('widgets.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-temp', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>