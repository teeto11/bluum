<?php $__env->startSection('profile-main'); ?>
    <section class="summary">
        <?php if(auth()->user() && auth()->user()->role == 'EXPERT' && auth()->user()->id == $expert->id): ?>
            <a href="<?php echo e(route('expert.posts')); ?>" class="posts" ><i class="fa fa-bookmark-o"></i>Posts<br><?php echo e($totalPost); ?></a>
            <a href="<?php echo e(route('expert.answers')); ?>" class="question" ><i class="fa fa-question-circle"></i>Answers<br><?php echo e($totalAnswers); ?></a>
        <?php else: ?>
            <a href="<?php echo e(route('expert.guest.posts', ['id'=>$expert->id])); ?>" class="posts" ><i class="fa fa-bookmark-o"></i>Posts<br><?php echo e($totalPost); ?></a>
            <a href="<?php echo e(route('expert.guest.answers', ['id'=>$expert->id])); ?>" class="question" ><i class="fa fa-question-circle"></i>Answers<br><?php echo e($totalAnswers); ?></a>
        <?php endif; ?>
    </section>
    <section class="page-posts">
        <div class="container post-container">
            <div class="card-head">
                <h3 class="">Recent Posts.</h3>
            </div>
            <div class="posts bg-success" style="margin-bottom: 2rem;" >
                <div class="posts__head" style="padding-left:10px;padding-right: 10px;">
                    <div class="posts__topic">Post</div>
                    <div class="posts__category">Category</div>
                    <div class="posts__replies">Likes</div>
                    <div class="posts__replies">Replies</div>
                    <div class="posts__views">Views</div>
                    <div class="posts__activity">Activity</div>
                </div>
                <div class="posts__body">
                    <?php $counter = 1; ?>
                    <?php $__currentLoopData = $recentPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="posts__item <?php echo e(($counter%2 == 0) ? 'bg-f2f4f6' : ''); ?>">
                        <div class="posts__section-left">
                            <div class="posts__topic">
                                <div class="posts__content">
                                    <a href="#">
                                        <h3><?php echo e(ucwords($post->title)); ?></h3>
                                    </a>
                                    <div class="posts__tags tags">
                                        <?php $tags = explode(',', $post->tags) ?>
                                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="#" class="bg-4f80b0"><?php echo e($tag); ?></a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="posts__category"><a href="#" class="category"><i class="bg-4436f8"></i><?php echo e(ucfirst($post->category)); ?></a></div>
                        </div>
                        <div class="posts__section-right">
                            <div class="posts__replies" ><?php echo e($post->likes); ?></div>
                            <div class="posts__replies"><?php echo e($post->replies->count()); ?></div>
                            <div class="posts__views"><?php echo e($post->views); ?></div>
                            <div class="posts__activity"><?php echo e(getLastActivityTime($post->updated_at)); ?></div>
                        </div>
                    </div>
                        <?php $counter++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
    <section class="questions" style="margin-top: 2rem" >
        <div class="table-row">
            <div class="bg-white">
                <h3 class="" style="font-size:20px;">Recent Responses</h3><hr>
                <table class="table table-borderless table-hover">
                    <thead>
                    <tr>
                        <th scope="" style="width:80%">Body</th>
                        <th></th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $recentResponses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $response): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(ucfirst($response->body)); ?></td>
                            <td class="text-right" >
                                <?php
                                if($response->post->type == 'QUESTION'):
                                    $route = route('question.show', ['id'=>$response->post->id, 'title'=>formatUrlString($response->post->title)]);
                                else:
                                    $route = route('blog.post', ['id'=>$response->post->id, 'title'=>formatUrlString($response->post->title)]);
                                endif;
                                ?>
                                <a href="<?php echo e($route); ?>" class=""><i class="fa fa-eye text-light"></i></a>
                            </td>
                            <td class="text-right" >
                                <?php if(auth()->user() && auth()->user()->role == 'EXPERT' && auth()->user()->id == $expert->id): ?>
                                    <form action="<?php echo e(route('expert.post.reply.delete')); ?>" method="post" >
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <input type="hidden" name="id" value="<?php echo e($response->id); ?>" >
                                        <button type="submit" style="background: transparent;border: none" ><i class="fa fa-trash text-danger"></i></button>
                                    </form>
                                    <a href="" class=""></a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('expert.layout.profile', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>