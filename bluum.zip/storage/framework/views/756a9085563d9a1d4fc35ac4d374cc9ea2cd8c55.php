<?php $__env->startSection('content'); ?>
    <div class="content-wrapper px-4">
        <div class="view-questions-wrapper">
            <div class="table-row">
                <div class="table-responsive bg-white px-4">
                    <h3 class="">All Questions</h3><hr>
                    <table class="table table-striped table-hover">
                        <thead>
                        <tr>
                            <th scope="" style="width:20%">User</th>
                            <th scope="" style="width:40%">Question</th>
                            <th scope="" style="width:20%">Date</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(ucwords($question->user->firstname.' '.$question->user->lastname)); ?></td>
                                <td><?php echo e(ucwords($question->title)); ?></td>
                                <td><?php echo e(date('M d, Y', strtotime($question->created_at))); ?></td>
                                <td><a href="/admin/question/<?php echo e($question->id); ?>" class="btn btn-warning"><i class="fa fa-eye text-light"></i></a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="my-3" >
            <?php echo e($questions->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>