<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('widgets.top-nav-bar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <main>
        <div class="container">
            <div class="create">
                <form action="<?php echo e(route('blog.post.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="create__head">
                        <div class="create__title"><img src="<?php echo e(asset('fonts/icons/main/New_Topic.svg')); ?>" alt="New topic">Create New Post</div>
                    </div>
                    <?php if($errors->has('title')): ?>
                        <span class="invalid-feedback text-danger" role="alert">
                            <strong><p><?php echo e($errors->first('title')); ?></p></strong>
                        </span>
                    <?php endif; ?>
                    <div class="create__section">
                        <label class="create__label" for="title"><?php echo e(__('Title')); ?></label>
                        <input type="text" class="form-control" name="title" id="title" />
                    </div>
                    <?php if($errors->has('category')): ?>
                        <span class="invalid-feedback text-danger" role="alert">
                            <strong><p><?php echo e($errors->first('category')); ?></p></strong>
                        </span>
                    <?php endif; ?>
                    <div class="create__section">
                        <label class="create__label" for="category"><?php echo e(__('Select Category')); ?></label>
                        <label class="custom-select">
                            <select id="category" name="category">
                                <option hidden ></option>
                                <?php $__currentLoopData = $categories->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->value); ?>" ><?php echo e(ucwords($category->value)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                    </div>
                    <?php if($errors->has('post')): ?>
                        <span class="invalid-feedback text-danger" role="alert">
                            <strong><p><?php echo e($errors->first('post')); ?></p></strong>
                        </span>
                    <?php endif; ?>
                    <div class="create__section create__textarea">
                        <label class="create__label" for="post"><?php echo e(__('Post')); ?></label>
                        <textarea class="form-control" id="post" name="post" ></textarea>
                    </div>
                    <?php if($errors->has('tags')): ?>
                        <span class="invalid-feedback text-danger" role="alert">
                            <strong><p><?php echo e($errors->first('tags')); ?></p></strong>
                        </span>
                    <?php endif; ?>
                    <div class="create__section">
                        <label class="create__label" for="tags" ><?php echo e(__('Add Tags')); ?></label>
                        <input type="text" class="form-control" id="tags" name="tags" placeholder="e.g. nature, science">
                    </div>
                    <div class="create__footer">
                        <button type="reset" href="#" class="create__btn-cansel btn"  >Cancel</button>
                        <button type="submit" class="create__btn-create btn btn--type-02" ><?php echo e(__('Create Post')); ?></button>
                    </div>
                </form>
            </div>
            <section class="page-posts">
                <div class="container">
                    <div class="card-head text-center">
                        <h3 class="h2">Recent Posts.</h3>
                    </div>
                    <div class="posts">
                        <div class="posts__head">
                            <div class="posts__topic">Post</div>
                            <div class="posts__category">Category</div>
                            <div class="posts__users">By</div>
                            <div class="posts__replies">Replies</div>
                            <div class="posts__views">Views</div>
                            <div class="posts__activity">Activity</div>
                        </div>
                        <div class="posts__body">
                            <?php if($recent_posts): ?>
                                <?php $__currentLoopData = $recent_posts->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="posts__item">
                                        <div class="posts__section-left">
                                            <div class="posts__topic">
                                                <div class="posts__content">
                                                    <a href="#">
                                                        <h3><?php echo e($post->title); ?></h3>
                                                    </a>
                                                    <div class="posts__tags tags">
                                                        <?php $__currentLoopData = explode(',',$post->tags); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <a href="#" class="bg-4f80b0"><?php echo e($tag); ?></a>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="posts__category"><a href="#" class="category"><i class="bg-368f8b"></i><?php echo e(ucwords($post->category)); ?></a></div>
                                        </div>
                                        <div class="posts__section-right">
                                            <div class="posts__users">
                                                <a href="#" class="category"><i class="bg-368f8b"></i><?php echo e(ucwords($post->user->lastname[0].'. '.$post->user->firstname)); ?></a>
                                            </div>
                                            <div class="posts__replies"><?php echo e(count($post->replies)); ?></div>
                                            <div class="posts__views"><?php echo e($post->views); ?></div>
                                            <div class="posts__activity"><?php echo e(getLastActivityTime($post->updated_at)); ?></div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </main>
    <?php echo $__env->make('widgets.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-temp', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>