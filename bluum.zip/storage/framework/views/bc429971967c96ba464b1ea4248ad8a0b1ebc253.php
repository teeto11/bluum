<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('widgets.top-nav-bar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <main>
        <div class="container">
            <div class="create">
                <form action="<?php echo e(route('blog.post.update', $post->id)); ?>" method="POST">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="create__head">
                        <div class="create__title"><img src="<?php echo e(asset('fonts/icons/main/New_Topic.svg')); ?>" alt="New topic">Create New Post</div>
                    </div>
                    <?php if($errors->has('title')): ?>
                        <span class="invalid-feedback text-danger" role="alert">
                            <strong><p><?php echo e($errors->first('title')); ?></p></strong>
                        </span>
                    <?php endif; ?>
                    <div class="create__section">
                        <label class="create__label" for="title"><?php echo e(__('Title')); ?></label>
                        <input type="text" class="form-control" name="title" id="title" value="<?php echo e($post->title); ?>" />
                    </div>
                    <?php if($errors->has('category')): ?>
                        <span class="invalid-feedback text-danger" role="alert">
                            <strong><p><?php echo e($errors->first('category')); ?></p></strong>
                        </span>
                    <?php endif; ?>
                    <div class="create__section">
                        <label class="create__label" for="category"><?php echo e(__('Select Category')); ?></label>
                        <label class="custom-select">
                            <select id="category" name="category">
                                <option hidden ></option>
                                <?php $__currentLoopData = $categories->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->value); ?>" <?php echo e(($category->value == $post->category) ? 'selected' : ''); ?> ><?php echo e(ucwords($category->value)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                    </div>
                    <?php if($errors->has('post')): ?>
                        <span class="invalid-feedback text-danger" role="alert">
                            <strong><p><?php echo e($errors->first('post')); ?></p></strong>
                        </span>
                    <?php endif; ?>
                    <div class="create__section create__textarea">
                        <label class="create__label" for="post"><?php echo e(__('Post')); ?></label>
                        <textarea class="form-control" id="post" name="post" ><?php echo e($post->body); ?></textarea>
                    </div>
                    <?php if($errors->has('tags')): ?>
                        <span class="invalid-feedback text-danger" role="alert">
                            <strong><p><?php echo e($errors->first('tags')); ?></p></strong>
                        </span>
                    <?php endif; ?>
                    <div class="create__section">
                        <label class="create__label" for="tags" ><?php echo e(__('Add Tags')); ?></label>
                        <input type="text" class="form-control" id="tags" name="tags" placeholder="e.g. nature, science" value="<?php echo e($post->tags); ?>">
                    </div>
                    <div class="create__footer">
                        <button type="reset" href="#" class="create__btn-cansel btn"  >Cancel</button>
                        <button type="submit" class="create__btn-create btn btn--type-02" ><?php echo e(__('Update Post')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </main>
    <?php echo $__env->make('widgets.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-temp', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>