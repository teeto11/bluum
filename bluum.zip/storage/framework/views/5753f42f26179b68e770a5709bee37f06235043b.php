<?php $__env->startSection('profile-main'); ?>
    <section class="nav">
        <div class="container" >
            <div class="nav__categories js-dropdown">
                <div class="nav__select">
                    <div class="btn-select" data-dropdown-btn="categories">All Categories</div>
                    <nav class="dropdown dropdown--design-01" data-dropdown-list="categories">
                        <ul class="dropdown__catalog row">
                            <li class="col-xs-6"><a href="<?php echo e(route('expert.posts')); ?>" class="category"><i class="bg-5dd39e"></i>All</a></li>
                            <?php if(auth()->user() && auth()->user()->role == 'EXPERT' && auth()->user()->id == $expert->id): ?>
                                <li class="col-xs-6"><a href="<?php echo e(route('expert.posts.viewByCategory', formatUrlString('pregnancy'))); ?>" class="category"><i class="bg-5dd39e"></i>Pregnancy</a></li>
                                <li class="col-xs-6"><a href="<?php echo e(route('expert.posts.viewByCategory', formatUrlString('medical travels'))); ?>" class="category"><i class="bg-c49bbb"></i>Medical Travels</a></li>
                                <li class="col-xs-6"><a href="<?php echo e(route('expert.posts.viewByCategory', formatUrlString('common illness'))); ?>" class="category"><i class="bg-525252"></i>Common Illness</a></li>
                                <li class="col-xs-6"><a href="<?php echo e(route('expert.posts.viewByCategory', formatUrlString('special illness'))); ?>" class="category"><i class="bg-777da7"></i>Special Illness</a></li>
                            <?php else: ?>
                                <li class="col-xs-6"><a href="<?php echo e(route('expert.guest.posts.viewByCategory', ['id'=>$expert->id, 'category'=>formatUrlString('pregnancy')])); ?>" class="category"><i class="bg-5dd39e"></i>Pregnancy</a></li>
                                <li class="col-xs-6"><a href="<?php echo e(route('expert.guest.posts.viewByCategory', ['id'=>$expert->id, 'category'=>formatUrlString('medical travels')])); ?>" class="category"><i class="bg-c49bbb"></i>Medical Travels</a></li>
                                <li class="col-xs-6"><a href="<?php echo e(route('expert.guest.posts.viewByCategory', ['id'=>$expert->id, 'category'=>formatUrlString('common illness')])); ?>" class="category"><i class="bg-525252"></i>Common Illness</a></li>
                                <li class="col-xs-6"><a href="<?php echo e(route('expert.guest.posts.viewByCategory', ['id'=>$expert->id, 'category'=>formatUrlString('special illness')])); ?>" class="category"><i class="bg-777da7"></i>Special Illness</a></li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
            </div>
            <div class="nav__menu js-dropdown">
                <div class="nav__select">
                    <div class="btn-select" data-dropdown-btn="menu">Latest</div>
                    <div class="dropdown dropdown--design-01" data-dropdown-list="menu">
                        <ul class="dropdown__catalog">
                            <?php if(auth()->user() && auth()->user()->role == 'EXPERT' && auth()->user()->id == $expert->id): ?>
                                <li><a href="<?php echo e(route('expert.posts')); ?>">Latest</a></li>
                                <li><a href="<?php echo e(route('expert.posts.popular')); ?>">Most Liked</a></li>
                            <?php else: ?>
                                <li><a href="<?php echo e(route('expert.guest.posts', $expert->id)); ?>">Latest</a></li>
                                <li><a href="<?php echo e(route('expert.guest.posts.popular', $expert->id)); ?>">Most Liked</a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
                <ul>
                    <?php if(auth()->user() && auth()->user()->role == 'EXPERT' && auth()->user()->id == $expert->id): ?>
                        <li class="active" ><a href="<?php echo e(route('expert.posts')); ?>">Latest</a></li>
                        <li><a href="<?php echo e(route('expert.posts.popular')); ?>">Most Liked</a></li>
                    <?php else: ?>
                        <li class="active" ><a href="<?php echo e(route('expert.guest.posts', $expert->id)); ?>">Latest</a></li>
                        <li><a href="<?php echo e(route('expert.guest.posts.popular', $expert->id)); ?>">Most Liked</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </section>
    <section class="posts">
        <div class="container" >
            <div class="posts__head">
                <div class="posts__topic">Post</div>
                <div class="posts__category">Category</div>
                <div class="posts__replies">Comment</div>
                <div class="posts__views">Views</div>
                <div class="posts__activity" id="post_actions"></div>
            </div>
            <div class="posts__body">
                <?php $counter = 1; ?>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="posts__item <?php echo e(($counter%2 == 0) ? 'bg-f2f4f6' : ''); ?>">
                        <div class="posts__section-left">
                            <div class="posts__topic">
                                <div class="posts__content">
                                    <a href="<?php echo e(route('blog.post', [$post->id, formatUrlString($post->title)])); ?>">
                                        <h3><?php echo e(ucwords($post->title)); ?></h3>
                                    </a>
                                    <div class="posts__tags tags">
                                        <?php $tags = explode(',', $post->tags) ?>
                                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="#" class="bg-4f80b0"><?php echo e($tag); ?></a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="posts__category"><a href="<?php echo e(route('blog.category', formatUrlString($post->category))); ?>" class="category"><i class="bg-4436f8"></i><?php echo e(ucfirst($post->category)); ?></a></div>
                        </div>
                        <div class="posts__section-right">
                            <div class="posts__replies"><?php echo e($post->replies->count()); ?></div>
                            <div class="posts__views"><?php echo e($post->views); ?></div>
                            <?php if(auth()->user() && $expert->id == auth()->user()->id): ?>
                                <div class="posts__activity" id="post_actions" >
                                    <div>
                                        <a href="<?php echo e(route('blog.post.edit', $post->id)); ?>" class=""><i class="fa fa-pencil"></i></a>
                                    </div>
                                    <div>
                                        <form action="<?php echo e(route('expert.post.delete')); ?>" method="post" >
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <input type="hidden" name="id" value="<?php echo e($post->id); ?>" >
                                            <button type="submit" style="background: transparent;border: none;box-shadow: none;" ><i class="fa fa-trash text-danger"></i></button>
                                        </form>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php $counter++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php echo e($posts->links()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('expert.layout.profile', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>