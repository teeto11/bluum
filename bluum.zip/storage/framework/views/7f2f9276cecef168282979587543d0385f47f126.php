<?php $__env->startSection('header_scripts'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/hover.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('widgets.top-nav-bar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="profile-wrapper" style="margin-top: 5rem" >
        <div class="container profile-sub-wrapper">
            <div class="profile-sidebar">
                <div class="profile-sidebar-header">
                    <img src="<?php echo e(asset('fonts/icons/avatars/'.getFirstLetterUppercase($expert->firstname)).'.svg'); ?>" class="" alt="">
                    <p><?php echo e(ucwords($expert->firstname.' '.$expert->lastname)); ?></p>
                </div>
                <div class="profile-sidebar-social hvr-float">
                    <div class="followers">
                        <p><i class="fa fa-users"></i> Followers <br> <span><?php echo e($totalFollowers); ?></span></p>
                    </div>
                    <div class="post">
                        <p><i class="fa fa-sticky-note"></i> Post <br> <span><?php echo e($totalPost); ?></span></p>
                    </div>
                </div>
                <?php if(auth()->user() && auth()->user()->id == $expert->id): ?>
                    <div class="text-center" style="margin-top: 1rem">
                        <a href="<?php echo e(route('expert.edit')); ?>" class="edit-btn hvr-pulse" style=""><i class="fa fa-edit"></i> Edit</a>
                    </div>
                <?php elseif(auth()->user() && $following): ?>
                    <form action="<?php echo e(route('expert.unfollow')); ?>" method="post" >
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($expert->id); ?>">
                        <button type="submit" class="btn hvr-grow">UnFollow <i class="fa fa-minus-circle"></i></button>
                    </form>
                <?php else: ?>
                    <form action="<?php echo e(route('expert.follow')); ?>" method="post" >
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($expert->id); ?>">
                        <button type="submit" class="btn hvr-grow">Follow <i class="fa fa-plus-circle"></i></button>
                    </form>
                <?php endif; ?>
                <div class="profile-sidebar-body">
                    <ul>
                        <li><b><i class="fa fa-briefcase"></i> Profession : </b><?php echo e(ucwords($personalInfo->expertise)); ?></li>
                        <li><b><i class="fa fa-gears"></i> Work Experience : </b><?php echo e($personalInfo->experience); ?><?php echo e(($personalInfo->experience > 1) ? 'Years' : 'Year'); ?></li>
                    </ul>
                </div>
            </div>
            <div class="profile-main">
                <?php echo $__env->yieldContent('profile-main'); ?>
            </div>
        </div>
    </div>
    <?php echo $__env->make('widgets.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-temp', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>