<?php $__env->startSection('profile-main'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.profile', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>