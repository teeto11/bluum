<!-- FOOTER -->
<footer>
    <div class="footer__head">
        <div class="container">
            <div class="row">
                <div class="footer__links col-sm-12 col-xs-6 col-md-2">
                    <ul>
                        <li class="link__head">Company</li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i> About Us</a></li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i> Contact Us</a></li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i> Careers</a></li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i> Terms &amp; Conditions</a></li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i> Privacy Policy</a></li>
                    </ul>
                </div>
                <div class="footer__links col-sm-12 col-xs-6 col-md-2">
                    <ul>
                        <li class="link__head">Learn More</li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i> FAQ</a></li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i> Q &amp; A</a></li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i> Learn</a></li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i> Ask an Expert</a></li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i> Events</a></li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i> Site Guidelines</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="footer__bottom">
        <span>2018 &copy; Bluumhealth. All rights reserved.</span>
    </div>
</footer>
